## BasePopup更新日志

* **【Candy】2.1.5-alpha**(2018/12/23)
  * 适配刘海屏全面平（双显示屏暂不适配）
  * 感谢[#114](https://github.com/razerdp/BasePopup/issues/114)的提供~
  * **Release年后发布，如果您有需要，请更新到此candy版。**

* **【Release】2.1.4**(2018/12/21)
  * **建议更新到这个版本！**
  * 非常抱歉~因为一时疏忽忘记合并一些东西，导致2.1.3版本在不拦截事件的情况下，无anchorView弹窗会导致位置问题，在2.1.4重新合并了代码，对此造成的影响，深表歉意。
    * 以后的版本一定会经过3个或以上的candy迭代仔细检查后再发！

* **【Release】2.1.3**(2018/12/21)
  * 正式发布2.1.3release
  * 增加[**linkTo(View)**](https://github.com/razerdp/BasePopup/wiki/API#linktoview-anchorview)方法
  * 支持update方法来跟随view或者指定位置更新
  * 全面优化系统原有的popupwindow定位方法，全版本统一。
  * 2.x的坑基本补完
  * 19年，我们再见-V-

* **【Candy】2.1.3-alpha2**(2018/12/20)
  * 增加`linkTo(View)`方法，跟随anchorView状态？一个方法就足够了~
  * 2.x的坑基本补完~如无意外，这个功能将会是18年最后一个功能性更新了

<img src="https://github.com/razerdp/Pics/blob/master/BasePopup/wiki/linkto/linkto.gif" height="360"/>

* **【Candy】2.1.3-alpha**(2018/12/19)
  * 支持update方法来跟随view或者指定位置更新
  * 调用`updatePopup()`方法即可~
  * 全面覆盖系统原有的popupwindow定位方法，全版本统一。

<img src="https://github.com/razerdp/Pics/blob/master/BasePopup/wiki/update/update.gif" height="360"/>

* **【Release】2.1.2**(2018/12/19)
  * 正式发布2.1.2release
  * 增加指定位置弹出的方法[**showPopupWindow(int x, int y)**](https://github.com/razerdp/BasePopup/blob/master/lib/src/main/java/razerdp/basepopup/BasePopupWindow.java#L681)
  * 修复内容宽高超过屏幕后`ClipToScreen()`修正不正确的问题
  * 输入法适配修复 fixed [#107](https://github.com/razerdp/BasePopup/issues/107)
  * preview:

<img src="https://github.com/razerdp/Pics/blob/master/BasePopup/wiki/anypos/anypos.gif" height="360"/>

* **【Release】2.1.1**(2018/12/13)
  * 针对setAlignBackground()失效的问题修复

* **【Release】2.1.0**(2018/12/12)
  * **双12大礼包~**
  * wiki大更新，留了大半年的坑终于快补完了，有问题请看[**wiki**](https://github.com/razerdp/BasePopup/wiki)
  * 正式发布2.1.0release
  * 2.1.0是对2.0的半彻底优化~为啥是一半呢？总得保留提升空间嘛嘿嘿
  * 更新的功能请看下方Candy的描述

* **【Candy】2.1.0-betaX**(2018/12)
  * **针对2.x的重构，撒花~**
  * 本次更新内容：
    * 去掉每次都add两次View的骚操作，合并成同一个PopupWindow，所以Layout Inspector不再让人迷惑为啥有两个PopupWindow了
    * 增加Gravity的支持，再也不用蛋疼的去计算蛋疼的offset了，而且布局文件真的可以wrap_content了
    * 接管layout过程，所以各个版本的PopupWindow都不一样？不存在滴。。。同时autoLocate支持RecyclerView啦~
    * 增加对contentView的xml的解析（前提是使用createPopupById方法），再也不怕被强制设置宽高了
    * fullScreen支持输入法布局适配！心塞了好久的问题终于解决
    * 增加对5.1和5.1.1官方两个PopupWindow重叠后在切换时层次变化的bug的适配
    * 优化代码，去除冗余代码
    * README大翻新

* **【Release】2.0.8.1**(2018/10/29)
  * **建议更新到这个版本！**
  * fixed [#94](https://github.com/razerdp/BasePopup/issues/94)
  * 紧急修复一个严重的bug[#95](https://github.com/razerdp/BasePopup/issues/95)，感谢[@tpnet](https://github.com/tpnet)
  * 优化代码

* **【Release】2.0.8**(2018/10/29)
  * fixed [#93](https://github.com/razerdp/BasePopup/issues/93)
  * 修复部分崩溃问题，发布release

* **2.0.8-alpha3**(2018/10/25)
  * fixed [#87](https://github.com/razerdp/BasePopup/issues/87)、[#89](https://github.com/razerdp/BasePopup/issues/89)、[#90](https://github.com/razerdp/BasePopup/issues/90)

* **2.0.8-alpha2**(2018/10/19)
  * 修复QuickPopupBuilder的click事件无响应问题，增加background方法
  * 修复设置background(0)时无法找到资源而崩溃的问题

* **2.0.7**(2018/10/15)
  * 绕开Android P的非公开api方法反射
    * 思路参考&&感谢[android_p_no_sdkapi_support](https://github.com/Guolei1130/android_p_no_sdkapi_support)
  * 发布2.0.7 release

* **2.0.6**(2018/10/09)
  * 不再抽象强制实现入场和退场动画
  * 针对自动弹出输入法的Popup，在dismiss()中默认关闭输入法

* 2018/09/30
  * 针对Match_Parent的dismissOutSide适配
  * 因为代码默认处理childCount==1的情况，如果有别的情况需要忽略点击的view，请调用setIgnoreDismissView()指定
  * 删除~~onInitDismissClickView()~~方法

* 2018/09/19
  * 继续丰富QuickPopupBuilder
  * 增加Demo:根据某个View控制各个方向的Popup。[示例](https://github.com/razerdp/BasePopup/blob/HEAD/app/src/main/java/razerdp/demo/fragment/LocatePopupFrag.java)
  
* **2.0.1-alpha2**(2018/09/06)
  * 增加快速构建QuickPopupBuilder
  * 尝试修复[#59](https://github.com/razerdp/BasePopup/issues/59)

* **2.0.1-alpha1** (2018/08/22)
  * 修复无法在onCreate()里面显示的问题
  * 增加setBackground(Drawable/ResourceId)方法，fixed [#79](https://github.com/razerdp/BasePopup/issues/79)
  * 正式版即将发布，。

* 2018/05/23
  * 添加注释

* 2018/05/14
  * **2.0.0-alpha1(candy)**

* 2018/04/19
  * 发布1.9.4(release) 
  * 修复autolocate的问题

* 2018/04/11
  * 1.9.4-alpha2(candy)
  * 修复误打包测试代码的alpha1

* 2018/04/09
  * 1.9.4-alpha(candy)
  * 本版本是预览版本，如果您有需要，可以更新到Candy版本，但不保证没有任何问题
  * 针对8.0进行修复
      * link: [issue#56](https://github.com/razerdp/BasePopup/issues/56)
      * link: [issue#61](https://github.com/razerdp/BasePopup/issues/61)
      * link: [issue#64](https://github.com/razerdp/BasePopup/issues/64)
  * 优化代码，HackWindowManager与HackPopupDecorView部分重构
  * showOnTop/showOnDown更名->onAnchorTop/onAnchorBottom，避免误导。

* 2018/01/23
  * 修复了在popup外滑动时`ViewGroup.LayoutParams`的cast异常
      * link: [issue#52](https://github.com/razerdp/BasePopup/issues/52)

* 2018/01/10
  * 发布1.9.2
  * 修复`HackDecorView`针对PopupWindow高度问题
  * 增加`setBlurBackgroundEnable()`模糊设置回调，允许自定义模糊操作
  * 修改为默认子线程模糊背景，同时增加blurImageView的模糊等待操作

* 2018/01/02
  * 修复可能出现的死循环问题以及去掉manifest文件冲突的问题
  * 部分方法名字修改，默认关闭 Log，如果您需要打印内部调试日志，请使用该方法：`BasePopupWindow.debugLog(true)`
  * 增加位移动画（百分比传值）,位移动画名字修正：`getTranslateAnimation()` -> `getTranslateVerticalAnimation()`
  * 模糊背景功能已经开放，针对单个View的模糊方法开放
  * 模糊背景允许子线程执行，默认主线程执行
  * gradle请在`defaultConfig`下添加两句：
    * renderscriptTargetApi 25
    * enderscriptSupportModeEnabled true
  * 发布1.9.1，其余bug修复

* 2017/12/28
  * 增加了一个window用于模糊层，增加模糊功能
    *  如果您需要模糊功能，仅仅需要调用一个方法：`setBlurBackgroundEnable()`
    * gradle请在`defaultConfig`下添加两句：
      * renderscriptTargetApi 25
      * enderscriptSupportModeEnabled true

* 2017/12/27
  * 增加演示demo：`DismissControlPopupFrag`
  * 增加两个方法用于touchEvent监听：`onTouchEvent()`&`onOutSideTouch()`
  * `HackPopupDecorView`继承`ViewGroup`而非`FrameLayout`，以解决PopupWindow的`decorView.getLayoutParams()`无法强转为`WindowManager.LayoutParams`的异常
  * 其余问题暂时没发现

* 2017/12/25 （圣诞节快乐~）
  * `BasePopupWindowProxy`和`PopupWindowProxy`权限收拢，不暴露放开
  * 优化`SimpleAnimUtil`，修改部分动画时间和插值器
  * 增加`setOutsideTouchable()`方法，和`setDismissWhenTouchOutside()`搭配使用有奇效哦
  * 增加`BasePopupHelper`优化`BasePopupWindow`代码可读性
  * 动画方面修正`AnimaView.clearAnimation()`->`Animation.cancel()`
  * 优化`showOnTop()`/`showOnDown()`方法。。。虽然可能没什么人用
  * 1.8.8版本因为一些问题而去除[#50](https://github.com/razerdp/BasePopup/issues/50)，替换为1.8.9
  * 【已解决】`setBackPressEnable()`在M以上已经可以自行决定是否允许返回键dismiss了，同时开放了keyEvent
    * 解决方案：[1.8.9 解决方案](https://github.com/razerdp/BasePopup/blob/master/%E5%85%B3%E4%BA%8EAndorid%20M%E4%BB%A5%E4%B8%8AsetBackPressEnable()%E5%A4%B1%E6%95%88%E7%9A%84%E9%97%AE%E9%A2%98%E7%9A%84%E5%88%86%E6%9E%90.md#189-%E8%A7%A3%E5%86%B3%E6%96%B9%E6%A1%88)
    * issue:[#33](https://github.com/razerdp/BasePopup/issues/33)
    * `BasePopupWindow`增加两个方法用于keyEvent的监听：`onDispatchKeyEvent()`&`onBackPressed()`
    * 感谢诸位热烈的讨论~
  * 部分方法名更改
    * `setOutsideTouchable()`->`setInterceptTouchEvent()`，该方法会影响焦点问题，即便是解决了`backPress`若这个方法设置为false，依然不会响应backpress
    

* 2017/11/27
  * 抽取`PopupWindowProxy`->`BasePopupWindowProxy`
  * 归类各种蛋疼的`showAsDropDown`适配->`PopupCompatManager`
  * 修正部分命名和方法名以及注释名错误的问题
    * 感谢简书小伙伴的评论，否则我还真发现不了。。。
    * 评论地址：[点我](http://www.jianshu.com/p/069f57e14a9c#comment-17669137)
    * 根据简书id，只能猜测他的github id：(Chenley)[https://github.com/Chenley]，如果您见到并发现我这个猜测是错的，请及时联系我-V-
    * 非常感谢你们的issue
  * 修复部分issue：[#46](https://github.com/razerdp/BasePopup/issues/46)

* 2017/09/20
  * 构造器不再限定为activity，context采用弱引用

* 2017/07/03
  * 集中修复了offset计算问题、7.0的showAsDropDown的问题，如果您还有什么疑问，请在issue里面提出

* 2017/01/12
  * 使用PopupWindowProxy，覆写dismiss();

* 2016-12-12
  * 现在`showPopupWindow(View v)`或者`showPopupWindow(int resid)`将会把popupwindow与anchorView挂钩哦，左上角会对齐（width=match_parent除外）
  * 另外增加一个执行popup前的回调`OnBeforeShowCallback`，与beforedismiss一样，返回false则不执行showpopup，另外在这里可以先实现offsetX或者offsetY哦~
  * 详情看[issue11](https://github.com/razerdp/BasePopup/issues/11)

* 2016-12-07
  * `ondismissListener`增加`onBeforeDismiss()`方法，在执行dismiss之前根据该值确定是否执行dismiss
  * 也可以在执行dismiss前执行一些操作，详情操作请看`SlideFromTopPopupFrag.java`



* 2016-12-06
  * 因为某些情况下需要用到showAsDropDown，因此增加dropdown方法`setShowAtDown()`详情看issue:[#issue10](https://github.com/razerdp/BasePopup/issues/10)
  * 另外增加一个点击popup外部不消失的方法，默认点击外部消失`setDismissWhenTouchOuside()`
  * 去除复杂的setRelativePivot方法，更新demo工程


* 2016-12-02
  * 修复setOnDismissListener的错误 [#issue9](https://github.com/razerdp/BasePopup/issues/9)


* 2016-11-23
  * 构造方法的view点击事件设置问题修复/getInputView必须返回edittext

* 2016-11-23
 * 增加了一些方法：
   * `setRelativePivot()`：该方法用于设置popup的参考中心点（相对于anchorView左上角）,使用注解，@RelativePivot
     * 在上述方法的前提下，增加了偏移量的方法
       * `setOffsetX()`:x偏移量，跟中心点有关,假如参考点在右边，那么正数则是远离参考view，负数相反，类似于margin
       * `setOffsetX()`:y偏移量，同上

 * `setAutoLocatePopup()`:设置popup是否自适配屏幕，当popup显示位置不足以支撑其完整显示的时候，将会自动调整(比如上方正常显示，在下方无法显示的时候则显示在上方)
   * 此时同样可以使用上述方法`setRelativePivot()`等

 * `getPopupViewWidth()/getPopupViewHeight()`:在创建view的时候就进行了view.measure，但是不能保证这两个值是完全可信的(比如popup内部是个listview?)
 * `setRelativeToAnchorView()`:是否参考锚点view，事实上，如果使用了`setRelativePivot()`，该值自动为ture
 * `setPopupGravity()`:设置poup的gravity，虽然一般情况下不建议设置，毕竟它的gravity很多时候都是相对于整个rootView来说的，容易混乱



* 2016-10-11
  * 修正api>21下出现的popup无法突破状态栏的问题(method:setPopupWindowFullScreen(boolean))

* 2016-05-20
  * 增加了popup的淡入淡出效果，道理很简单。。。弄回sytle，同时开放style的设置方法。淡入淡出效果是默认的，如果您不需要淡入淡出效果，可以通过setNeedPopupFade（false）取消

* 2016-05-20
  * 因为发现展示了Popup后，如果不断地dismiss，会导致动画重复播放，然后最终留下一个蒙层，因此加入了防止执行动画过程中再次被执行的标志
下一阶段期望增加：蒙层淡入淡出的方法

* 2016-05-18
  * 降低最高版本要求23->21，因为开发过程中发现有时候需要dismiss动画有时候不需要，因此增加dismissWithOutAnima方法

* 2016-03-05
  * 修改名字ViewCreate->BasePopup

* 2016-02-23
  * 去除master分支的兼容包，最低要求api 16，需要兼容到2.3请查看master-api 9分支

* 2016-01-28
  * 修改了BasePopupWindow，将部分抽象方法改为public，防止子类继承的时候必须实现过多无用方法，保持整洁性。

* 2016-01-28 因为好奇，研究了一下插值器，发现了一个很好玩的网站http://inloop.github.io/interpolator/ </br>
这个网站有着可视化插值器和公式，于是这回就把公式集成了下来，做出了各种插值器的popup，但其实只有第一个最好玩，其他的马马虎虎。这次的自定义插值器是继承LinearInterpolator然后通过网站上的公式进行计算后复写对应接口实现的。同时将BasePopupWindow的一些anima变量改为protected。
  * CustomInterpolatorPopup.java:
    * ![image](https://github.com/razerdp/BasePopup/blob/master/img/interpolator_popup.gif)

* 2016-01-25 修复了inputView无法自动弹出输入法的问题（原因可能是因为popup在show出来后才可以获取焦点，而我们的inputview一开始就findViewById出来了），所以可能是null。

* 2016-01-25 增加了一个好玩的其实并无卵用的的dialog popup，看着好玩~gif图因为帧率问题，高帧慢，低帧丢细节，所以看起来效果不太好，实际效果很好玩的-V-</br>
  * DialogPopup.java:
    * ![image](https://github.com/razerdp/BasePopup/blob/master/img/dialog_popup.gif)

* 2016-01-23 忽然发现一直以来提交代码的帐号是我的子帐号，现在切换回来。。。。

* 2016-01-22 增加了一个常见的菜单式的popup(demo)，关于动画问题，我配置的是简单的缩放和透明度变化，可以按照个人爱好定义,顺便修正了BasePopupWindow的一个小小的坑</br>
  * MenuPopup.java:
    *![image](https://github.com/razerdp/BasePopup/blob/master/img/menu_popup.gif)

* 2016-01-20 增加了包含listview的popup(demo)，这个popup将采用builder模式构造，同时点击事件可以通过绑定clickTag来建立一个映射关系，这样就不用判断点击的位置来执行对应的步骤（当然，点击位置这个传统的操作还是保留的）</br>
  * ListPopup.java:
    * ![image](https://github.com/razerdp/BasePopup/blob/master/img/list_popup.gif)

* 2016-01-19 稍微重构BasePopupWindow，在构造器把getXXX各种get方法赋值，防止每次调用的时候都new一个对象导致的性能问题&因为对象地址不对导致的各种奇葩问题</br>

* 2016-01-18 增加了含有输入框的popup(demo)，同时修复了dismiss由于调用getExitAnima()但是setListener/addListener无效的问题（原因是getExitAnima()属于重新new出来的动画，调用多次后，listener指向的并非同一个对象，所以无效）</br>
  * InputPopup.java:
    * ![image](https://github.com/razerdp/BasePopup/blob/master/img/input_popup.gif)

* 2016-01-16 增加仿朋友圈评论的popup(demo)</br>

* 同日的16:39 尝试添加了退出动画
  * ![image](https://github.com/razerdp/BasePopup/blob/master/img/comment_popup_with_exitAnima.gif)
    * 解析:http://blog.csdn.net/mkfrank/article/details/50532956

* CommentPopup.java(该frag标题名字忘改回来了。。。录制了gif也就懒得动了):
  * ![image](https://github.com/razerdp/BasePopup/blob/master/img/comment_popup.gif)

* 2016-01-15 增加两种继承basepopup实现的常见Popup(demo)</br>
  * ScalePopup.java:
    * ![image](https://github.com/razerdp/BasePopup/blob/master/img/scale_popup.gif)
      * 解析:http://blog.csdn.net/mkfrank/article/details/50523702

* SlideFromBottomPopup.java:
  * ![image](https://github.com/razerdp/BasePopup/blob/master/img/slide_from_bottom_popup.gif)
    * 解析：http://blog.csdn.net/mkfrank/article/details/50527159

