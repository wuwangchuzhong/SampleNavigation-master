package razerdp.demo.base.baseadapter;

import android.view.View;

/**
 * Created by 大灯泡 on 2017/4/19.
 */
public interface BaseListViewHolder {
    void onInFlate(View rootView);
}
