package razerdp.demo.base.baseadapter;

/**
 * Created by 大灯泡 on 2017/4/27.
 */

public abstract class OnRecyclerViewLongItemClickListener<T> extends OnBaseRecyclerViewLongItemClickListener<T, BaseRecyclerViewHolder<T>> {

}
