package razerdp.basepopup;

/**
 * Created by 大灯泡 on 2018/11/29.
 */
interface PopupKeyboardStateChangeListener {

    void onKeyboardChange(int keyboardHeight, boolean isVisible);

}
