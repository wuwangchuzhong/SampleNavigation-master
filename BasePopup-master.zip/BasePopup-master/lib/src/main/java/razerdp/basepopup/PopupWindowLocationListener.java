package razerdp.basepopup;

/**
 * Created by 大灯泡 on 2018/11/29.
 */
interface PopupWindowLocationListener {

    void onAnchorTop();

    void onAnchorBottom();

}
