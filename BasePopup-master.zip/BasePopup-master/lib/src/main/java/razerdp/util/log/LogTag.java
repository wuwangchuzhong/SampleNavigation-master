package razerdp.util.log;

/**
 * Created by 大灯泡 on 2017/12/27.
 */
public enum LogTag {
    i, d, w, e, v
}
